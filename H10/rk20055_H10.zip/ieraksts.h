struct Ieraksts{
    int atslega;
    char vards[30];
};

struct posPair{
    bool kursFails;
    unsigned long pozicija;
};